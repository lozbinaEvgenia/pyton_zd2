
import random
# Генерация случайного числа от 1 до 100
# secret_number = random.randint(1, 100)
# attempts = 0

# print("Я загадал число от 1 до 100. Попробуйте угадать его!")

# while True:
#     # Ввод числа от пользователя
#     guess = int(input("Введите ваше число: "))
#     attempts += 1  # Увеличиваем счетчик попыток

#     # Проверка введенного числа
#     if guess < secret_number:
#         print("Загаданное число больше.")
#     elif guess > secret_number:
#         print("Загаданное число меньше.")
#     else:
#         print(f"Поздравляю! Вы угадали число {secret_number} за {attempts} попыток.")
#         break  # Выход из цикла, если число угадано
# Ввод строки символов
# input_string = input("Введите строку символов, разделенных пробелами: ")

# # Разделение строки на символы
# characters = input_string.split()

# # Инициализация вложенного списка для группировки символов
# grouped_characters = []

# # Переменная для хранения текущей группы символов
# current_group = []

# # Проход по всем символам
# for char in characters:
#     # Если текущая группа пуста или символ совпадает с последним в группе
#     if not current_group or char == current_group[-1]:
#         current_group.append(char)
#     else:
#         # Добавляем текущую группу в общий список и начинаем новую группу
#         grouped_characters.append(current_group)
#         current_group = [char]

# # Не забываем добавить последнюю группу, если она не пустая
# if current_group:
#     grouped_characters.append(current_group)

# # Вывод результата
# print(grouped_characters)
# Определяем карты и их достоинства
# cards = {
#     '6': 2,
#     '7': 2,
#     '8': 2,
#     '9': 2,
#     '10': 2,
#     'J': 2,
#     'Q': 3,
#     'K': 4,
#     'A': 11
# }

# # Создаем колоду карт
# deck = list(cards.keys()) * 4  # 4 масти

# # Перемешиваем колоду
# random.shuffle(deck)

# # Изначально у пользователя 0 очков
# points = 0

# print("Добро пожаловать в игру с картами!")
# while True:
#     # Спрашиваем пользователя, хочет ли он взять карту
#     choice = input("Хотите взять карту? (y/n): ").lower()
    
#     if choice == 'n':
#         print(f"Вы набрали {points} очков. Спасибо за игру!")
#         break
#     elif choice == 'y':
#         # Снимаем последнюю карту из колоды
#         card = deck.pop()
#         points += cards[card]  # Прибавляем к очкам достоинство карты
#         print(f"Вы взяли карту: {card}. Текущие очки: {points}")

#         # Проверяем количество очков
#         if points > 21:
#             print(f"Вы проиграли! У вас {points} очков.")
#             break
#         elif points == 21:
#             print("Поздравляю! Вы выиграли с 21 очком!")
#             break
#     else:
#         print("Пожалуйста, введите 'y' или 'n'.")